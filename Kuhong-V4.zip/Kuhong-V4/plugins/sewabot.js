let handler = async m => m.reply(`
╭━SEWA BOT BY HAJAR
│ *「 INFO BOT 」*
│➛ *Nama Bot* : HajarBOT
│➛ *Versi* : V10.0
│➛ *Creator* : Hajar^v^
╰┬────────────┈ ⳹
    │ *「HARGA SEWA 」* 
    │➛ *1 BULAN* : 10K
    │➛ *2 BULAN* : 20K
    │➛ *4 BULAN* : 40K
    ╰─────────────┈ ⳹
    
     Minat?? wa.me/6281271336229
`.trim()) // Tambah sendiri kalo mau
handler.help = ['sewabot']
handler.tags = ['info']
handler.command = /^(sewabot)$/i

module.exports = handler
