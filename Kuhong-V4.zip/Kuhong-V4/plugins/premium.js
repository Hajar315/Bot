let handler = async m => m.reply(`
╭─「 BUY PREMIUM 」
│ 
│ > Keuntungan :
│• Limit Tidak Terbatas!
│• Fitur Premium Dapat Digunakan!
│• Dapat Menambahkan Bot Ke Grup!
│
│ > Bonus :
│• Diberikan Kode Gift Seminggu!
│
│ > Harga :
│• 10K / Bulan (4 Minguu)
│• 20K / 2 Bulan (8 Minggu)
│• 50K / VIP (Permanen)
│
│ > Pembayaran :
│• GOPAY/DANA
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['buypremium']
handler.tags = ['info']
handler.command = /^(buypremium)$/i

module.exports = handler
