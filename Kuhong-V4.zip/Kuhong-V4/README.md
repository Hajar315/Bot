# Selamat Datang di Github Kuhong-V4 <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="50px">
<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Developer.gif" width="500px">

## Ada Bug, Erorr, atau mau Request? <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/happy.gif" width="30px">
[`Chat Admin`](https://wa.me/62895337278647)
Atau Bisa Lewat Issue :)

### FOR TERMUX USER
```bash
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> git clone https://github.com/RC047/Kuhong-V4
> cd Kuhong-V4
> npm install
```
###### Run
```bash
> node RendyGans
```
---------

### FOR WINDOWS/VPS/RDP USER
* Download And Install Git [`Click Here`](https://git-scm.com/downloads) <br>
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download) <br>
* Download And Install FFMPEG [`Click Here`](https://ffmpeg.org/download.html) (don't forget to path) 
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php) (if nulis want work,  checklist columns 1,2,3,5,6) 
```bash
> git clone https://github.com/RC047/Kuhong-V4
> cd Kuhong-V4
> npm install
```
###### Run
```bash
> node . [<session name>] (session name is optional)
```
--------------

## Fitur Bot <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Medal.gif" width="30px">

| BOT SYSTEM | YES
| :---------------------------------------------: | :-----------: |
| Daftar |✅|
| Leveling |✅|
| Anti Link |✅|
| Anti Virtex |✅|
| Anti Toxic |✅|
| Anti Delete Pesan |✅|
| Perintah Tidak Ditemukan |✅|


| +18 | YES |
| :-----------------: | :-------: |
| Kode Nuklir |✅|
| Random Hentai |✅|


|  CREATOR  |                                           YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker |✅|
| Sticker Gif Maker |✅|
| Convert Sticker To Image |✅|
| Harta Tahta |✅|
| TextPro Maker |✅|
| Photooxy Maker |✅|
| Ephoto360 Maker |✅|
| QR Code |✅|
| Custom Harta Tahta |✅|
| Glitchtext Maker |✅|
| PornHub Logo Maker |✅|
| Nulis Tugas |✅|
| Quotes Maker  |✅|


| DOWNLOADER | YES |
| :-----------------: | :-------: |
| YTMP4 |✅|
| YTMP3 |✅|
| YT PLAY |✅|
| INSTAGRAM |✅|
| FACEBOOK |✅|
| TWITTER |✅|


| PRIMBON | YES |
| :-----------------: | :-------: |
| Artinama |✅|
| Info Zodiak |✅|


| SPAMMER | YES |
| :-----------------: | :-------: |
| PizzaHut |✅|
| DanaCinta |✅|
| SpamCall |✅|
| SpamSMS |✅|
| SpamWA |✅|

| EDUCATION | YES |
| :-----------------: | :-------: |
| Brainly |✅|
| Belajar |✅|


| IMAGE | YES |
| :-----------------: | :-------: |
| Google Image |✅|
| Pinterest |✅|
| Anime |✅|
| Kpop |✅|
| Foto Cewek |✅|
| Foto Cowok |✅|


| GROUP | YES |
| :-----------------: | :-------: |
| AFK |✅|
| Anti Link |✅|
| Link Group |✅|
| Promote Member |✅|
| Demote Member |✅|
| Hide Tag |✅|
| Add Member |✅|
| Kick Member |✅|
| Welcome & Bye Group |✅|
| Delete Pesan |✅|


| RANDOM | YES |
| :-----------------: | :-------: |
| Quotes |✅|
| Pantun |✅|
| Kata Bijak |✅|
| Puisi |✅|
| Syair |✅|
| Fakta Unik |✅|


| FUN | YES |
| :-----------------: | :-------: |
| Math |✅|
| Tebak Gambar |✅|
| Slot Machine |✅|
| Dadu |✅|
| Truth or Dare |✅|
| IQ Test |✅|
| Alay |✅|
| Hilih |✅|


| OWNER | YES |
| :-----------------: | :-------: |
| Set Prefix |✅|
| Set Menu |✅|
| Set Welcome & Bye |✅|
| Banned Member |✅|
| Unbanned Member |✅|
| Broadcast |✅|
| Group Broadcast |✅|
| Clear All Chat |✅|


| PREMIUM MENU | YES |
| :-----------------: | :-------: |
| Jadi Bot |✅|
| Join GC |✅|


 TENTANG BOT | YES |
| :-----------------: | :-------: |
| Report |✅|
| Request Fitur |✅|
| Info Bot |✅|
| Status Bot |✅|
| Donasi |✅|
| Info Premium |✅|

* Masih Banyak Lagi
--------------

# MEDIA SOSIAL <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="30px">

#### YouTube : [`RC047`](https://www.youtube.com/c/RC047)
#### Instagram : [`@rendycraft047`](https://www.instagram.com/rendycraft047)
#### Kontak : [`WhatsApp`](https://wa.me/62895337278647)
#### Donasi : [`Seikhlasnya :)`](https://saweria.co/RC047)

#### API Rest : [`kuhong-api`](https://kuhong-api.herokuapp.com/)
#### Created By : [`Nurutomo`](https://GitHub.com/Nurutomo) 
#### Recoded By : [`RC047`](https://GitHub.com/RC047) 
